<?php

class ParseError extends Error
{
}
