<?php
interface MockTestInterface
{
    public function returnAnything();
    public function returnAnythingElse();
}
